
import { GoogleGenAI } from "@google/genai";

export const generateConceptualImage = async (prompt: string): Promise<string | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
  
  const systemPrompt = `
    Create a conceptual 2D FLAT vector illustration.
    STYLE RULES:
    - 2D Flat, clean vectors.
    - NO texture, NO noise, NO grain.
    - NO realistic shadows, NO 3D volume.
    - NO cinematic lighting, NO lens flares.
    - NO text, NO labels, NO numbers, NO typography (Persian or English).
    - Palette: Backgrounds: #0F172A, #111827. Accents: #22D3EE, #8B5CF6, #22C55E.
    - Outlines: 2px uniform stroke.
    - Focus: Human gestures, body language, hands, distance between bodies.
    - Mood: Professional, premium, minimalist.
    CONTENT: ${prompt}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-image",
      contents: [{ parts: [{ text: systemPrompt }] }],
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Image generation failed:", error);
    return null;
  }
};
